from django.shortcuts import render


servicios = [
    {
        "nombre": "Desarrollo de Sitios Web",
        "resumen": "Sitios y aplicaciones web a medida, rápidos y responsivos para tu negocio.",
        "descripcion": "Desarrollamos sitios y aplicaciones web a medida, adaptados a las necesidades de cada empresa.",
        "caracteristicas": [
            "Diseño responsivo",
            "Desarrollo a medida",
            "Optimización de rendimiento",
            "Soporte post-entrega"
        ],
        "precio": "$450.000",
        "duracion": "3 a 6 semanas"
    },

    {
        "nombre": "Aplicaciones Móviles",
        "resumen": "Apps nativas e híbridas para Android e iOS, conectadas a tus sistemas.",
        "descripcion": "Creamos aplicaciones móviles para Android e iOS integradas con los sistemas de tu empresa.",
        "caracteristicas": [
            "Aplicaciones Android e iOS",
            "Diseño intuitivo",
            "Integración con sistemas",
            "Soporte post-entrega"
        ],
        "precio": "$890.000",
        "duracion": "6 a 10 semanas"
    },

    {
        "nombre": "Consultoría en la Nube",
        "resumen": "Migración y optimización de infraestructura en la nube para tu empresa.",
        "descripcion": "Ayudamos a las empresas a migrar y optimizar sus sistemas e infraestructura en la nube.",
        "caracteristicas": [
            "Migración a la nube",
            "Optimización de infraestructura",
            "Seguridad",
            "Monitoreo"
        ],
        "precio": "$600.000",
        "duracion": "2 a 4 semanas"
    },

    {
        "nombre": "Ciberseguridad para Pymes",
        "resumen": "Protege los datos de tu empresa y de tus clientes con buenas prácticas reales.",
        "descripcion": "Implementamos medidas de seguridad para proteger la información y los sistemas de las pequeñas y medianas empresas.",
        "caracteristicas": [
            "Evaluación de seguridad",
            "Protección de datos",
            "Buenas prácticas de seguridad",
            "Asesoría especializada"
        ],
        "precio": "$350.000",
        "duracion": "2 a 3 semanas"
    }
]


def servicios_view(request):
    context = {
        "servicios": servicios
    }

    return render(request, "servicios.html", context)


def detalle_servicio(request, id):
    servicio = servicios[id - 1]

    context = {
        "servicio": servicio
    }

    return render(request, "detalle.html", context)


def home(request):
    return render(request, "index.html")


def nosotros(request):
    return render(request, "nosotros.html")


def contacto(request):
    return render(request, "contacto.html")