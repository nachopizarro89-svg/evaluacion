from django.apps import AppConfig


class ProyectobaseConfig(AppConfig):
    name = 'Proyectobase'
